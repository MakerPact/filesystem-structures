Welcome to the PARA Method!

PARA stands for Projects, Areas, Resources, and Archives. It organizes information based on actionability (how soon you need to use it).

--- HOW TO USE ---
1. PROJECTS: Active tasks with a deadline (e.g., "Complete Web Design").
2. AREAS: Ongoing responsibilities with no deadline (e.g., "Health", "Finances").
3. RESOURCES: Topics of interest or reference material (e.g., "Recipes", "Coding Tips").
4. ARCHIVES: Inactive items from the other three categories.

--- EXAMPLES ---

1. PERSONAL USE
   - Projects: "Plan Wedding", "Buy New Car"
   - Areas: "Health", "Home Maintenance", "Family"
   - Resources: "Cooking Recipes", "Travel Bucket List"
   - Archive: "2023 Tax Return", "Old Apartment Lease"

2. BUSINESS USE
   - Projects: "Launch Product X", "Hire Sales Manager"
   - Areas: "Marketing Strategy", "Product Development", "Accounting"
   - Resources: "Brand Assets", "Competitor Research", "Templates"
   - Archive: "Discontinued Product Y", "2020 Financials"

3. STUDENT USE
   - Projects: "Write History Thesis", "Apply for Internships"
   - Areas: "Biology Degree", "Student Council", "Part-time Job"
   - Resources: "Citation Styles", "Study Guides", "Research Papers"
   - Archive: "Freshman Year Notes", "Completed Assignments"
