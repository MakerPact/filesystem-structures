#!/bin/bash
# This script creates a chronological folder structure for the current year.

YEAR=$(date +%Y)
BASE_DIR="Filing Cabinet/Chronological Filing System"

# Array of month subdirectories
months=(
    "01_January"
    "02_February"
    "03_March"
    "04_April"
    "05_May"
    "06_June"
    "07_July"
    "08_August"
    "09_September"
    "10_October"
    "11_November"
    "12_December"
)

# Create the main year directory and all month subdirectories
for month in "${months[@]}"; do
    mkdir -p "$BASE_DIR/$YEAR/$month"
done

echo "Chronological folder structure for $YEAR created successfully in '$BASE_DIR'."
