Welcome to the Johnny Decimal Filing System!

This system organizes files using a numbering scheme (Category -> Area -> ID). It ensures everything has a specific place and can be found quickly.

--- HOW TO USE ---
Files are grouped into broad 'Areas' (10-19, 20-29, etc.), then specific 'Categories' (11, 12, etc.), and finally individual 'IDs' (11.01, 11.02).

--- EXAMPLES ---

1. PERSONAL USE
   - 10-19 Personal
     - 11 Finances
       - 11.01 Banking: Statements, correspondence
       - 11.02 Taxes: Yearly returns, receipts
     - 12 Health
       - 12.01 Medical Records: Vaccinations, checkups

2. BUSINESS USE
   - 20-29 Work
     - 21 Projects
       - 21.01 Website Redesign: Design assets, specs
       - 21.02 Q3 Marketing: Ad copy, budget
     - 22 Admin
       - 22.01 Invoices: Sent and received
       - 22.02 Contracts: Legal agreements

3. STUDENT USE
   - 50-59 University
     - 51 Classes
       - 51.01 Math 101: Homework, exams
       - 51.02 History 202: Essays, reading list
     - 52 Admin
       - 52.01 Enrollment: Transcripts, fees
